export default class Button {
    constructor(props) {
        this.props = Object.assign({ variant: 'primary', size: 'large', disabled: false, loading: false }, props);
        this.element = document.createElement('button');
        this.element.type = 'button';
        this.element.className = this.getClassNames();
        this.element.disabled = !!this.props.disabled;
        this.element.setAttribute('tabindex', '0');
        this.element.style.position = 'relative';
        // Icon (left)
        if (this.props.icon) {
            this.iconEl = document.createElement('span');
            this.iconEl.className = 'button-icon button-icon-left';
            this.iconEl.innerHTML = this.props.icon;
            this.element.appendChild(this.iconEl);
        }
        // Label
        this.labelEl = document.createElement('span');
        this.labelEl.className = 'button-label';
        this.labelEl.textContent = this.props.label;
        this.element.appendChild(this.labelEl);
        // Spinner (right, if loading)
        if (this.props.loading) {
            this.spinnerEl = this.createSpinner();
            this.element.appendChild(this.spinnerEl);
        }
        // Click handler
        if (this.props.onClick) {
            this.element.addEventListener('click', (e) => {
                if (!this.props.disabled && !this.props.loading) {
                    this.props.onClick(e);
                }
            });
        }
    }
    getClassNames() {
        const { variant, size, disabled, loading } = this.props;
        return [
            'button',
            `button-${variant}`,
            `button-${size}`,
            disabled ? 'button-disabled' : '',
            loading ? 'button-loading' : '',
        ].filter(Boolean).join(' ');
    }
    createSpinner() {
        const spinner = document.createElement('span');
        spinner.className = 'button-spinner';
        spinner.innerHTML = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="2" opacity="0.2"/><path d="M15 8A7 7 0 1 1 8 1" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`;
        return spinner;
    }
    // Public API to update button state
    setLoading(loading) {
        this.props.loading = loading;
        this.element.className = this.getClassNames();
        if (loading && !this.spinnerEl) {
            this.spinnerEl = this.createSpinner();
            this.element.appendChild(this.spinnerEl);
        }
        else if (!loading && this.spinnerEl) {
            this.spinnerEl.remove();
            this.spinnerEl = undefined;
        }
        this.element.disabled = !!this.props.disabled || loading;
    }
    setDisabled(disabled) {
        this.props.disabled = disabled;
        this.element.className = this.getClassNames();
        this.element.disabled = !!disabled || !!this.props.loading;
    }
    setLabel(label) {
        this.props.label = label;
        this.labelEl.textContent = label;
    }
    setIcon(svg) {
        if (!this.iconEl) {
            this.iconEl = document.createElement('span');
            this.iconEl.className = 'button-icon button-icon-left';
            this.element.insertBefore(this.iconEl, this.labelEl);
        }
        this.iconEl.innerHTML = svg;
    }
    setVariant(variant) {
        this.props.variant = variant;
        this.element.className = this.getClassNames();
    }
    setSize(size) {
        this.props.size = size;
        this.element.className = this.getClassNames();
    }
}
