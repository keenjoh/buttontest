export type ButtonVariant = 'primary' | 'secondary' | 'tertiary';
export type ButtonSize = 'large' | 'small';

export interface ButtonProps {
    label: string;
    variant?: ButtonVariant;
    size?: ButtonSize;
    disabled?: boolean;
    loading?: boolean;
    icon?: string; // SVG string for left icon
    onClick?: (e: MouseEvent) => void;
}

export default class Button {
    public readonly element: HTMLButtonElement;
    private props: ButtonProps;
    private iconEl?: HTMLElement;
    private spinnerEl?: HTMLElement;
    private labelEl: HTMLElement;

    constructor(props: ButtonProps) {
        this.props = { variant: 'primary', size: 'large', disabled: false, loading: false, ...props };
        this.element = document.createElement('button');
        this.element.type = 'button';
        this.element.className = this.getClassNames();
        this.element.disabled = !!this.props.disabled;
        this.element.setAttribute('tabindex', '0');
        this.element.style.position = 'relative';

        // Icon (left)
        if (this.props.icon) {
            this.iconEl = document.createElement('span');
            this.iconEl.className = 'button-icon button-icon-left';
            this.iconEl.innerHTML = this.props.icon;
            this.element.appendChild(this.iconEl);
        }

        // Label
        this.labelEl = document.createElement('span');
        this.labelEl.className = 'button-label';
        this.labelEl.textContent = this.props.label;
        this.element.appendChild(this.labelEl);

        // Spinner (right, if loading)
        if (this.props.loading) {
            this.spinnerEl = this.createSpinner();
            this.element.appendChild(this.spinnerEl);
        }

        // Click handler
        if (this.props.onClick) {
            this.element.addEventListener('click', (e) => {
                if (!this.props.disabled && !this.props.loading) {
                    this.props.onClick!(e);
                }
            });
        }
    }

    private getClassNames(): string {
        const { variant, size, disabled, loading } = this.props;
        return [
            'button',
            `button-${variant}`,
            `button-${size}`,
            disabled ? 'button-disabled' : '',
            loading ? 'button-loading' : '',
        ].filter(Boolean).join(' ');
    }

    private createSpinner(): HTMLElement {
        const spinner = document.createElement('span');
        spinner.className = 'button-spinner';
        spinner.innerHTML = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="2" opacity="0.2"/><path d="M15 8A7 7 0 1 1 8 1" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>`;
        return spinner;
    }

    // Public API to update button state
    public setLoading(loading: boolean) {
        this.props.loading = loading;
        this.element.className = this.getClassNames();
        if (loading && !this.spinnerEl) {
            this.spinnerEl = this.createSpinner();
            this.element.appendChild(this.spinnerEl);
        } else if (!loading && this.spinnerEl) {
            this.spinnerEl.remove();
            this.spinnerEl = undefined;
        }
        this.element.disabled = !!this.props.disabled || loading;
    }

    public setDisabled(disabled: boolean) {
        this.props.disabled = disabled;
        this.element.className = this.getClassNames();
        this.element.disabled = !!disabled || !!this.props.loading;
    }

    public setLabel(label: string) {
        this.props.label = label;
        this.labelEl.textContent = label;
    }

    public setIcon(svg: string) {
        if (!this.iconEl) {
            this.iconEl = document.createElement('span');
            this.iconEl.className = 'button-icon button-icon-left';
            this.element.insertBefore(this.iconEl, this.labelEl);
        }
        this.iconEl.innerHTML = svg;
    }

    public setVariant(variant: ButtonVariant) {
        this.props.variant = variant;
        this.element.className = this.getClassNames();
    }

    public setSize(size: ButtonSize) {
        this.props.size = size;
        this.element.className = this.getClassNames();
    }
} 