# Custom Button Web Component

A reusable, Figma-accurate button web component. No framework required.

## Installation

Copy the `src/button.js` file into your project, or use it directly from your build system.

## Usage

1. **Include the component in your HTML:**

```html
<script type="module" src="./src/button.js"></script>
```

2. **Use the custom element in your HTML:**

```html
<!-- Default button -->
<custom-button>Click Me</custom-button>

<!-- With plus icon -->
<custom-button icon>Add Item</custom-button>

<!-- Loading state -->
<custom-button loading>Processing...</custom-button>

<!-- Disabled state -->
<custom-button disabled>Cannot Click</custom-button>
```

## Attributes

- `icon`: Shows the plus icon to the left of the text
- `loading`: Shows the loading spinner to the right of the text and disables the button
- `disabled`: Disables the button

## Events

The button fires standard `click` events. You can listen for them as you would with a normal button:

```js
const btn = document.querySelector('custom-button');
btn.addEventListener('click', () => {
  alert('Button clicked!');
});
```

## Styling

- The button is styled to match the Figma design (blue, rounded, bold, uppercase, etc.)
- The icon and spinner are pixel-perfect SVGs
- The gap between icon/text and spinner/text is 6px, as in the Figma file
- The component uses Shadow DOM for style encapsulation

## Customization

If you want to change the color, font, or other styles, you can edit the CSS in `button.js`.

## Example

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Button Demo</title>
  <script type="module" src="./src/button.js"></script>
</head>
<body>
  <custom-button icon>Save</custom-button>
  <custom-button loading>Loading</custom-button>
  <custom-button disabled>Disabled</custom-button>
</body>
</html>
```

---

**Ready to use in any web project!** 