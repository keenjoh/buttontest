// Button Web Component
class CustomButton extends HTMLElement {
  constructor() {
    super();
    const shadow = this.attachShadow({ mode: 'open' });
    
    // Create button element
    this.button = document.createElement('button');
    
    // Add styles
    const style = document.createElement('style');
    style.textContent = `
      :host {
        display: inline-block;
      }

      button {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        padding: 8px 16px;
        border: none;
        border-radius: 3px;
        font-family: 'Open Sans', sans-serif;
        font-weight: 700;
        font-size: 12px;
        line-height: 1.5em;
        letter-spacing: 0.083em;
        text-transform: uppercase;
        cursor: pointer;
        transition: background 0.2s, opacity 0.2s;
        background: #1F60E0;
        color: #FFFFFF;
      }
      
      button:hover:not(:disabled) {
        background: #184CB4;
      }
      
      button:active:not(:disabled) {
        background: #16449F;
      }
      
      button:disabled {
        background: rgba(12, 12, 12, 0.12);
        color: rgba(12, 12, 12, 0.38);
        cursor: not-allowed;
      }

      .loading {
        opacity: 0.6;
        pointer-events: none;
      }

      .spinner {
        animation: spin 1s linear infinite;
        width: 16px;
        height: 16px;
        margin-left: 6px;
        display: inline-flex;
        vertical-align: middle;
      }

      @keyframes spin {
        100% { transform: rotate(360deg); }
      }

      .icon {
        display: inline-flex;
        vertical-align: middle;
        width: 14px;
        height: 14px;
        padding: 0;
        box-sizing: content-box;
      }
      .icon svg {
        display: block;
        width: 14px;
        height: 14px;
        margin: 0;
        padding: 0;
      }
    `;
    
    shadow.appendChild(style);
    shadow.appendChild(this.button);

    // Add event listeners
    this.button.addEventListener('mouseenter', this.handleMouseEnter.bind(this));
    this.button.addEventListener('mouseleave', this.handleMouseLeave.bind(this));
    this.button.addEventListener('mousedown', this.handleMouseDown.bind(this));
    this.button.addEventListener('mouseup', this.handleMouseUp.bind(this));
  }
  
  static get observedAttributes() {
    return ['disabled', 'loading', 'icon'];
  }
  
  attributeChangedCallback(name, oldValue, newValue) {
    if (name === 'disabled') {
      this.button.disabled = newValue !== null;
      this.updateState();
    }
    if (name === 'loading') {
      this.updateState();
    }
    if (name === 'icon') {
      this.updateContent();
    }
  }
  
  connectedCallback() {
    this.updateContent();
    this.updateState();
  }

  updateContent() {
    const hasIcon = this.hasAttribute('icon');
    const isLoading = this.hasAttribute('loading');
    
    this.button.innerHTML = '';
    let content = '';
    if (hasIcon && !isLoading) {
      // Provided plus icon SVG
      content += `<span class="icon"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13 5.5H8.5V1C8.5 0.447812 8.05219 0 7.5 0H6.5C5.94781 0 5.5 0.447812 5.5 1V5.5H1C0.447812 5.5 0 5.94781 0 6.5V7.5C0 8.05219 0.447812 8.5 1 8.5H5.5V13C5.5 13.5522 5.94781 14 6.5 14H7.5C8.05219 14 8.5 13.5522 8.5 13V8.5H13C13.5522 8.5 14 8.05219 14 7.5V6.5C14 5.94781 13.5522 5.5 13 5.5Z" fill="white"/></svg></span>`;
    }
    content += `<span>${this.textContent || ''}</span>`;
    if (isLoading) {
      // Provided loading spinner SVG
      content += `<svg class="spinner" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.45636 1.70646C9.45636 2.50901 8.80578 3.15958 8.00323 3.15958C7.20069 3.15958 6.55011 2.50901 6.55011 1.70646C6.55011 0.903909 7.20069 0.253333 8.00323 0.253333C8.80578 0.253333 9.45636 0.903909 9.45636 1.70646ZM8.00323 12.8471C7.20069 12.8471 6.55011 13.4977 6.55011 14.3002C6.55011 15.1028 7.20069 15.7533 8.00323 15.7533C8.80578 15.7533 9.45636 15.1028 9.45636 14.3002C9.45636 13.4977 8.80578 12.8471 8.00323 12.8471ZM14.3001 6.55021C13.4976 6.55021 12.847 7.20078 12.847 8.00333C12.847 8.80588 13.4976 9.45646 14.3001 9.45646C15.1027 9.45646 15.7532 8.80588 15.7532 8.00333C15.7532 7.20078 15.1027 6.55021 14.3001 6.55021ZM3.15948 8.00333C3.15948 7.20078 2.50891 6.55021 1.70636 6.55021C0.903811 6.55021 0.253235 7.20078 0.253235 8.00333C0.253235 8.80588 0.903811 9.45646 1.70636 9.45646C2.50891 9.45646 3.15948 8.80588 3.15948 8.00333ZM3.55068 11.0028C2.74813 11.0028 2.09755 11.6533 2.09755 12.4559C2.09755 13.2584 2.74813 13.909 3.55068 13.909C4.35323 13.909 5.0038 13.2584 5.0038 12.4559C5.0038 11.6534 4.3532 11.0028 3.55068 11.0028ZM12.4558 11.0028C11.6532 11.0028 11.0027 11.6533 11.0027 12.4559C11.0027 13.2584 11.6532 13.909 12.4558 13.909C13.2583 13.909 13.9089 13.2584 13.9089 12.4559C13.9089 11.6534 13.2583 11.0028 12.4558 11.0028ZM3.55068 2.09765C2.74813 2.09765 2.09755 2.74823 2.09755 3.55078C2.09755 4.35333 2.74813 5.0039 3.55068 5.0039C4.35323 5.0039 5.0038 4.35333 5.0038 3.55078C5.0038 2.74823 4.3532 2.09765 3.55068 2.09765Z" fill="white"/></svg>`;
    }
    this.button.innerHTML = content;
  }

  updateState() {
    const isDisabled = this.hasAttribute('disabled');
    const isLoading = this.hasAttribute('loading');
    
    if (isDisabled) {
      this.state = 'disabled';
    } else if (isLoading) {
      this.state = 'loading';
      this.button.classList.add('loading');
    } else {
      this.button.classList.remove('loading');
    }
  }

  handleMouseEnter() {
    if (!this.hasAttribute('disabled') && !this.hasAttribute('loading')) {
      this.state = 'hover';
    }
  }

  handleMouseLeave() {
    if (!this.hasAttribute('disabled') && !this.hasAttribute('loading')) {
      this.state = 'default';
    }
  }

  handleMouseDown() {
    if (!this.hasAttribute('disabled') && !this.hasAttribute('loading')) {
      this.state = 'pressed';
    }
  }

  handleMouseUp() {
    if (!this.hasAttribute('disabled') && !this.hasAttribute('loading')) {
      this.state = 'hover';
    }
  }
}

// Register the custom element
customElements.define('custom-button', CustomButton); 